package com.example.bohra.savvysavingappfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FinanceStat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finance_stat);
    }
}
