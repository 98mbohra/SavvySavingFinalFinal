package com.example.bohra.savvysavingappfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SavingStat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saving_stat);
    }
}
